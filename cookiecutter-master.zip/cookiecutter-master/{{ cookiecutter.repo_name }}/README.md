{{ cookiecutter.project }}: {{ cookiecutter.repo_name }}
=============================

{{cookiecutter.description}}
