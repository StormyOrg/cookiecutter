def test_it() -> None:
    assert True
